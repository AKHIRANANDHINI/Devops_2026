const express = require("express");
const app = express();

// Home page
app.get("/", (req, res) => {
  res.send(`
    <h1>Welcome to My Express Website</h1>
    <p>This is the home page</p>
    <a href="/about">About</a><br>
    <a href="/contact">Contact</a>
  `);
});

// About page
app.get("/about", (req, res) => {
  res.send(`
    <h1>About Us</h1>
    <p>This website is built using Express.js</p>
    <a href="/">Back to Home</a>
  `);
});

// Contact page
app.get("/contact", (req, res) => {
  res.send(`
    <h1>Contact</h1>
    <p>Email: example@gmail.com</p>
    <a href="/">Back to Home</a>
  `);
});

// Server start
app.listen(3000, () => {
  console.log("Website running at http://localhost:3000");
});
