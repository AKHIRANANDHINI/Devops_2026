const express = require('express');
const app = express();

app.get('/address', (req, res) => {
  // Accessing query parameters from the URL, e.g., /address?zip=12345
  const zipCode = req.query.zip;
  console.log(`Requested zip code: ${zipCode}`);
  res.send(`Received request for zip code ${zipCode}`);
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
